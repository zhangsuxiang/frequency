#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author: Suxiang Zhang
"""

import os
import glob
import re
import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
from scipy.signal import spectrogram, hilbert, butter, filtfilt
from obspy import read, read_inventory, UTCDateTime
from obspy.signal.trigger import ar_pick, pk_baer
from obspy.geodetics import locations2degrees
import warnings
warnings.filterwarnings('ignore')

# === 地震学参数 ===
event_file    = "event.txt"
phase_file    = "phaseps_dp.dat"
seed_glob     = "*.seed"
pre_P, post_P = 10.0, 20.0
timezone_cst  = 8
output_dir    = "spectrogram_results_fixed"

# 地震学质量控制参数
MIN_SNR = 3.0                      
MAX_GAP_RATIO = 0.02               
MIN_DURATION = 15.0                

# 地球物理参数
EARTH_Q_FACTOR = 200               
CRUSTAL_VELOCITY = 6.0             
SITE_AMPLIFICATION = True          

components = ["BHZ", "BHN", "BHE"]
os.makedirs(output_dir, exist_ok=True)

# ----------------------------------------------------------------
# 基于地震学理论的频带选择
# ----------------------------------------------------------------
def seismic_frequency_selection(mag, hypo_dist, depth, vs30=None):
    """
    基于地震学理论选择频带
    """
    
    # 1. 震级控制的基础频带
    if mag <= 2.0:
        fc_base = 15.0  
        fmin_base, fmax_base = 3.0, 30.0
    elif mag <= 4.0:
        fc_base = 8.0
        fmin_base, fmax_base = 1.5, 25.0
    elif mag <= 6.0:
        fc_base = 3.0
        fmin_base, fmax_base = 0.5, 15.0
    else:
        fc_base = 1.0
        fmin_base, fmax_base = 0.1, 8.0
    
    # 2. 距离衰减修正
    if hypo_dist is not None:
        q_factor = EARTH_Q_FACTOR * (1 + depth/100)  
        
        # 高频衰减
        fmax_effective = fmax_base * np.exp(-np.pi * hypo_dist / (q_factor * CRUSTAL_VELOCITY))
        fmax = min(fmax_base, max(fmax_effective, 2.0))  
        
        # 低频在远距离保持较好
        if hypo_dist > 200:
            fmin = max(fmin_base * 0.5, 0.1)
        else:
            fmin = fmin_base
            
        # 近场效应
        if hypo_dist < 50:
            fmax = min(fmax * 1.5, 40.0)  
    else:
        fmin, fmax = fmin_base, fmax_base
    
    # 3. 深度效应
    if depth > 70:  
        fmin *= 0.8  
        fmax *= 1.1
    elif depth < 10:  
        fmax *= 1.2  
    
    # 4. 场地效应考虑
    if vs30 is not None and SITE_AMPLIFICATION:
        if vs30 < 300:  
            fmin *= 0.7  
            fmax *= 0.9  
        elif vs30 > 800:  
            fmin *= 1.1
            fmax *= 1.3  
    
    # 5. 仪器响应限制
    fmin = max(fmin, 0.01)  
    fmax = min(fmax, 40.0)   
    
    return fmin, fmax, fc_base

# ----------------------------------------------------------------
# 改进的时频分析参数
# ----------------------------------------------------------------
def optimal_spectrogram_params(fmin, fmax, fs, signal_duration):
    """
    基于信号特征优化时频分析参数
    """
    min_window = 3.0 / fmin  
    max_window = signal_duration / 10  
    window_sec = min(min_window, max_window, 4.0)  
    
    nperseg = int(window_sec * fs)
    
    # 重叠率：50-75%
    overlap_ratio = 0.65 if window_sec > 2.0 else 0.5
    noverlap = int(nperseg * overlap_ratio)
    
    # 确保窗长为合理值
    nperseg = max(nperseg, 64)  # 最小窗长
    noverlap = int(nperseg * overlap_ratio)
    
    return nperseg, noverlap

# ----------------------------------------------------------------
# P波特征频率识别
# ----------------------------------------------------------------
def identify_p_wave_characteristics(f, t, Sxx, p_time_idx):
    """
    自动识别P波的频率特征
    """
    characteristics = {}
    
    try:
        # P波前后时窗
        pre_window = slice(max(0, p_time_idx-5), p_time_idx)
        post_window = slice(p_time_idx, min(len(t), p_time_idx+10))
        
        if (pre_window.stop - pre_window.start > 0 and 
            post_window.stop - post_window.start > 0):
            
            # 噪声和信号谱
            noise_spectrum = np.mean(Sxx[:, pre_window], axis=1)
            signal_spectrum = np.mean(Sxx[:, post_window], axis=1)
            
            # 信噪比谱
            snr_spectrum = np.divide(signal_spectrum, noise_spectrum,
                                   out=np.ones_like(signal_spectrum), 
                                   where=noise_spectrum!=0)
            
            # 主频识别
            dominant_freq_idx = np.argmax(snr_spectrum)
            dominant_freq = f[dominant_freq_idx]
            
            # 有效频带
            effective_band = f[snr_spectrum > 2.0]
            
            characteristics = {
                'dominant_frequency': dominant_freq,
                'effective_band_min': effective_band.min() if len(effective_band) > 0 else f[0],
                'effective_band_max': effective_band.max() if len(effective_band) > 0 else f[-1],
                'max_snr': snr_spectrum.max(),
                'spectral_centroid': np.sum(f * signal_spectrum) / np.sum(signal_spectrum) if np.sum(signal_spectrum) > 0 else np.nan
            }
    
    except Exception as e:
        print(f"    P波特征识别失败: {e}")
        characteristics = {
            'dominant_frequency': np.nan,
            'effective_band_min': np.nan,
            'effective_band_max': np.nan,
            'max_snr': np.nan,
            'spectral_centroid': np.nan
        }
    
    return characteristics

# ----------------------------------------------------------------
# 增强的数据质量评估
# ----------------------------------------------------------------
def enhanced_quality_check(tr, p_time, fmin, fmax):
    """
    增强的数据质量检查
    """
    results = {
        'passed': True,
        'snr': 0.0,
        'frequency_snr': {},
        'issues': []
    }
    
    try:
        # 基础质量检查
        if tr.stats.npts < MIN_DURATION * tr.stats.sampling_rate:
            results['passed'] = False
            results['issues'].append(f"记录长度不足: {tr.stats.npts/tr.stats.sampling_rate:.1f}s")
            return results
        
        # 时域SNR
        try:
            noise_window = tr.copy()
            signal_window = tr.copy()
            
            noise_window.trim(endtime=p_time - 1)
            signal_window.trim(starttime=p_time, endtime=p_time + 5)
            
            if len(noise_window.data) > 10 and len(signal_window.data) > 10:
                noise_rms = np.sqrt(np.mean(noise_window.data**2))
                signal_rms = np.sqrt(np.mean(signal_window.data**2))
                
                if noise_rms > 0:
                    snr = signal_rms / noise_rms
                    results['snr'] = snr
                    
                    if snr < MIN_SNR:
                        results['passed'] = False
                        results['issues'].append(f"时域SNR过低: {snr:.1f}")
                else:
                    results['passed'] = False
                    results['issues'].append("噪声水平异常")
        except Exception as e:
            print(f"    SNR计算失败: {e}")
        
        # 检查饱和和削波
        max_amp = np.max(np.abs(tr.data))
        std_amp = np.std(tr.data)
        if std_amp > 0 and max_amp > std_amp * 50:
            results['passed'] = False
            results['issues'].append("数据饱和或存在削波")
    
    except Exception as e:
        results['passed'] = False
        results['issues'].append(f"质量检查失败: {str(e)}")
    
    return results

# ----------------------------------------------------------------
# 智能色标优化
# ----------------------------------------------------------------
def seismic_colormap_optimization(sxx_dict, time_array, p_characteristics):
    """
    基于地震学特征优化色标
    """
    all_data = []
    p_onset_data = []
    
    # P波初动时窗
    try:
        p_onset_mask = (time_array >= 0) & (time_array <= 3)
        
        for chan_data in sxx_dict.values():
            f2, t2, Sxx_db2, fs, snr = chan_data
            all_data.extend(Sxx_db2.ravel())
            
            if np.any(p_onset_mask):
                p_onset_data.extend(Sxx_db2[:, p_onset_mask].ravel())
        
        all_data = np.array(all_data)
        all_data = all_data[np.isfinite(all_data)]  # 移除无效值
        
        if len(p_onset_data) > 0:
            p_onset_data = np.array(p_onset_data)
            p_onset_data = p_onset_data[np.isfinite(p_onset_data)]
            
            # 基于P波段优化
            p_mean = np.nanmean(p_onset_data)
            p_std = np.nanstd(p_onset_data)
            
            vmax = p_mean + 2.0 * p_std
            vmin = p_mean - 3.0 * p_std
            
            # 确保合理范围
            if vmax - vmin < 15:
                center = (vmax + vmin) / 2
                vmin = center - 12
                vmax = center + 18
        else:
            # 回退方法
            vmin = np.nanpercentile(all_data, 15)
            vmax = np.nanpercentile(all_data, 85)
    
    except Exception as e:
        print(f"    色标优化失败: {e}")
        # 最简单的方法
        all_data = np.hstack([v[2].ravel() for v in sxx_dict.values()])
        all_data = all_data[np.isfinite(all_data)]
        vmin = np.nanpercentile(all_data, 10)
        vmax = np.nanpercentile(all_data, 90)
    
    return vmin, vmax

# ----------------------------------------------------------------
# 简化的P波到时精化
# ----------------------------------------------------------------
def simple_p_arrival_refinement(tr, initial_p_time):
    """
    简化的P波到时精化，避免复杂函数调用
    """
    try:
        # 截取P波前后各3秒
        t0 = initial_p_time - 3
        t1 = initial_p_time + 3
        tr_pick = tr.copy()
        tr_pick.trim(starttime=t0, endtime=t1)
        
        if len(tr_pick.data) < tr_pick.stats.sampling_rate * 3:
            return initial_p_time
        
        # 使用完整参数的ar_pick
        try:
            p_pick, s_pick = ar_pick(
                a=tr_pick.data,
                samp_rate=tr_pick.stats.sampling_rate,
                f1=1.0, f2=20.0,
                lta_p=1.0, sta_p=0.1,
                lta_s=4.0, sta_s=1.0,
                m_p=2, m_s=8,
                l_p=0.1, l_s=0.2
            )
            
            if p_pick is not None and 0 < p_pick < len(tr_pick.data):
                refined_time = t0 + p_pick / tr_pick.stats.sampling_rate
                # 限制修正量在合理范围内
                if abs(refined_time - initial_p_time) < 1.0:
                    return refined_time
        except Exception as e:
            print(f"    ar_pick失败，尝试简单方法: {e}")
        
        # 如果ar_pick失败，使用简单的STA/LTA
        data = tr_pick.data
        fs = tr_pick.stats.sampling_rate
        
        # 短时/长时窗长度
        sta_len = int(0.1 * fs)  # 0.1秒
        lta_len = int(1.0 * fs)  # 1秒
        
        if len(data) > lta_len + sta_len:
            sta_lta = np.zeros(len(data))
            
            for i in range(lta_len, len(data) - sta_len):
                lta = np.mean(data[i-lta_len:i]**2)
                sta = np.mean(data[i:i+sta_len]**2)
                if lta > 0:
                    sta_lta[i] = sta / lta
            
            # 寻找STA/LTA最大值
            max_idx = np.argmax(sta_lta)
            if sta_lta[max_idx] > 2.0:  # 阈值
                refined_time = t0 + max_idx / fs
                if abs(refined_time - initial_p_time) < 1.0:
                    return refined_time
        
    except Exception as e:
        print(f"    P波精化失败: {e}")
    
    return initial_p_time

# ----------------------------------------------------------------
# 主程序
# ----------------------------------------------------------------

# 解析事件信息
parts = open(event_file).read().split()
yr, mo, da, Hr, Min = map(int, parts[:5])
Sec = float(parts[5])
evla, evlo, evdp, evmag = map(float, parts[6:10])
origin = UTCDateTime(yr, mo, da, Hr, Min, Sec) - timezone_cst*3600

print(f"事件 (UTC): {origin.isoformat()}, ML={evmag:.1f}, 深度={evdp:.1f}km")
print(f"地震学优化版本 - Q={EARTH_Q_FACTOR}, Vc={CRUSTAL_VELOCITY}km/s")

# 读取P波到时
p_arrivals = {}
with open(phase_file) as pf:
    for line in pf:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        cols = re.split(r"\s+", line)
        if len(cols) >= 4 and cols[3].upper() == "P":
            sta_full = cols[0]
            dt_p = float(cols[1])
            if sta_full not in p_arrivals or dt_p < p_arrivals[sta_full]:
                p_arrivals[sta_full] = dt_p

print(f"共加载 {len(p_arrivals)} 个台站的 P 波到时")

# 分析结果存储
analysis_results = []

# 处理SEED文件
seed_files = sorted(glob.glob(seed_glob))
if not seed_files:
    raise FileNotFoundError(f"未找到任何 '{seed_glob}' 文件")

for seed_path in seed_files:
    print(f"\n=== 处理 {os.path.basename(seed_path)} ===")
    
    try:
        inv = read_inventory(seed_path, format="SEED")
        print("  ✓ 响应元数据载入")
    except Exception as e:
        inv = None
        print(f"  ! 无响应: {e}")
        continue
    
    st = read(seed_path)
    print(f"  ✓ 读取到 {len(st)} 条 Trace")
    
    # 预处理
    st.detrend("demean")
    st.detrend("linear")
    st.taper(0.05, type="hann")
    
    # 聚合三分量
    sta_dict = defaultdict(dict)
    for tr in st:
        key = tr.stats.network + tr.stats.station
        if tr.stats.channel in components:
            sta_dict[key][tr.stats.channel] = tr
    
    # 处理每个台站
    for sta_full, dt_p in p_arrivals.items():
        net, sta = sta_full[:2], sta_full[2:]
        if sta_full not in sta_dict:
            continue
        
        traces = sta_dict[sta_full]
        tP_abs = origin + dt_p
        
        # 计算震中距
        hypo_dist = None
        azimuth = None
        if inv:
            try:
                for network in inv:
                    for station in network:
                        if station.code == sta:
                            sta_lat = station.latitude
                            sta_lon = station.longitude
                            hypo_dist = locations2degrees(evla, evlo, sta_lat, sta_lon) * 111.195
                            azimuth = np.arctan2(sta_lon - evlo, sta_lat - evla) * 180 / np.pi
                            break
            except Exception as e:
                print(f"    ! 距离计算失败: {e}")
        
        # 地震学频带选择
        fmin, fmax, corner_freq = seismic_frequency_selection(evmag, hypo_dist, evdp)
        dist_str = f"{hypo_dist:.1f}km" if hypo_dist else "未知距离"
        print(f"\n  处理 {sta_full}: 震中距={dist_str}, 拐角频率={corner_freq:.2f}Hz")
        print(f"  地震学频带: {fmin:.2f}-{fmax:.2f} Hz")
        
        # 存储分量数据
        sxx_dict = {}
        p_characteristics_dict = {}
        
        # 处理各分量
        for chan in components:
            if chan not in traces:
                continue
            
            tr = traces[chan].copy()
            
            # 去仪器响应
            if inv:
                try:
                    pre_filt = [max(fmin*0.8, 0.005), fmin*0.9, fmax*1.1, min(fmax*1.5, tr.stats.sampling_rate*0.4)]
                    tr.remove_response(inventory=inv, output="VEL", pre_filt=pre_filt,
                                     zero_mean=True, taper=True, water_level=60)
                    print(f"    ✓ {chan} 去响应成功")
                except Exception as e:
                    print(f"    ! {chan} 去响应失败: {e}")
                    continue
            
            # P波到时精化（仅垂直分量）
            tP_abs_refined = tP_abs
            if chan.endswith('Z'):
                tP_abs_refined = simple_p_arrival_refinement(tr, tP_abs)
                if tP_abs_refined != tP_abs:
                    print(f"    P波到时精化: 修正了 {(tP_abs_refined - tP_abs):.3f} 秒")
            
            # 质量检查
            qc_result = enhanced_quality_check(tr, tP_abs_refined, fmin, fmax)
            if not qc_result['passed']:
                print(f"    ! {chan} 质量检查未通过: {', '.join(qc_result['issues'])}")
                continue
            else:
                print(f"    ✓ {chan} SNR={qc_result['snr']:.1f}")
            
            # 截取时窗
            t0 = tP_abs_refined - pre_P
            t1 = tP_abs_refined + post_P
            tr.trim(starttime=t0, endtime=t1, pad=True, fill_value=0)
            
            # 时频分析
            fs = tr.stats.sampling_rate
            signal_duration = post_P + pre_P
            nperseg, noverlap = optimal_spectrogram_params(fmin, fmax, fs, signal_duration)
            
            try:
                f, t, Sxx = spectrogram(tr.data, fs=fs, window='hann',
                                      nperseg=nperseg, noverlap=noverlap,
                                      scaling='density', mode='psd')
                
                Sxx_db = 10 * np.log10(Sxx + 1e-20)
                
                # 聚焦频带
                mask_f = (f >= max(fmin * 0.8, 0.1)) & (f <= min(fmax * 1.2, fs/2.2))
                f2 = f[mask_f]
                Sxx_db2 = Sxx_db[mask_f, :]
                
                # P波特征识别
                t_rel = t - pre_P
                p_time_idx = np.argmin(np.abs(t_rel))
                p_char = identify_p_wave_characteristics(f2, t_rel, Sxx_db2, p_time_idx)
                p_characteristics_dict[chan] = p_char
                
                sxx_dict[chan] = (f2, t_rel, Sxx_db2, fs, qc_result['snr'])
                
            except Exception as e:
                print(f"    ! {chan} 时频分析失败: {e}")
                continue
        
        if not sxx_dict:
            print(f"  跳过 {sta_full}（无有效数据）")
            continue
        
        # 色标优化
        try:
            time_ref = sxx_dict[list(sxx_dict.keys())[0]][1]
            vmin, vmax = seismic_colormap_optimization(sxx_dict, time_ref, p_characteristics_dict)
            print(f"  地震学色标: {vmin:.1f} 到 {vmax:.1f} dB/Hz")
        except Exception as e:
            print(f"  ! 色标优化失败: {e}")
            all_data = np.hstack([v[2].ravel() for v in sxx_dict.values()])
            vmin, vmax = np.nanpercentile(all_data, [10, 90])
        
        # 绘图
        try:
            fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=True, sharey=True)
            title = f"{net}.{sta} 地震学优化频谱图 (ML={evmag:.1f}"
            if hypo_dist:
                title += f", Δ={hypo_dist:.1f}km"
            title += f", fc={corner_freq:.1f}Hz, {fmin:.2f}-{fmax:.2f}Hz)"
            fig.suptitle(title, fontsize=14)
            
            pcm = None
            for idx, chan in enumerate(components):
                ax = axes[idx]
                
                if chan not in sxx_dict:
                    ax.text(0.5, 0.5, "No Data / QC Failed", ha="center", va="center",
                           transform=ax.transAxes, fontsize=12)
                    ax.set_ylabel("Freq [Hz]")
                    ax.set_title(f"{net}.{sta}.{chan}")
                    continue
                
                f2, t2, Sxx_db2, fs, snr = sxx_dict[chan]
                p_char = p_characteristics_dict.get(chan, {})
                
                # 绘制频谱图
                pcm = ax.pcolormesh(t2, f2, Sxx_db2, shading='gouraud',
                                   vmin=vmin, vmax=vmax, cmap='viridis')
                
                ax.set_yscale('log')
                ax.set_ylim(max(fmin, 0.1), min(fmax, fs/2.2))
                ax.set_ylabel("Freq [Hz]")
                
                # 标题
                dom_freq = p_char.get('dominant_frequency', np.nan)
                title_str = f"{net}.{sta}.{chan} (SNR={snr:.1f}"
                if not np.isnan(dom_freq):
                    title_str += f", Dom={dom_freq:.1f}Hz"
                title_str += ")"
                ax.set_title(title_str)
                
                # 标记线
                ax.axvline(0, color='white', linestyle='--', linewidth=2, alpha=0.8, label='P arrival')
                ax.axvspan(-1, 3, alpha=0.15, color='red', label='P-wave onset')
                
                # 标记特征频率
                if not np.isnan(dom_freq) and dom_freq >= f2.min() and dom_freq <= f2.max():
                    ax.axhline(dom_freq, color='yellow', linestyle=':', alpha=0.7, 
                              label=f'Dom: {dom_freq:.1f}Hz')
                if corner_freq >= f2.min() and corner_freq <= f2.max():
                    ax.axhline(corner_freq, color='orange', linestyle=':', alpha=0.7,
                              label=f'Corner: {corner_freq:.1f}Hz')
                
                if idx == 0:
                    ax.legend(loc='upper right', fontsize=8)
            
            axes[-1].set_xlabel("Time relative to P arrival [s]")
            axes[-1].set_xlim(-pre_P, post_P)
            
            # 颜色条
            if pcm is not None:
                fig.subplots_adjust(right=0.88)
                cbar_ax = fig.add_axes([0.90, 0.15, 0.02, 0.7])
                cbar = fig.colorbar(pcm, cax=cbar_ax)
                cbar.set_label('PSD [dB/Hz]', fontsize=12)
            
            plt.tight_layout()
            
            # 保存
            output_file = os.path.join(output_dir, f"{net}_{sta}_seismic_fixed.png")
            plt.savefig(output_file, dpi=300, bbox_inches='tight')
            print(f"  保存: {output_file}")
            
            # 结果记录
            result_entry = {
                'network': net,
                'station': sta,
                'distance_km': hypo_dist,
                'azimuth_deg': azimuth,
                'corner_frequency_hz': corner_freq,
                'frequency_band_hz': [fmin, fmax],
                'p_wave_characteristics': p_characteristics_dict,
                'colormap_range_db': [vmin, vmax]
            }
            analysis_results.append(result_entry)
            
            plt.show()
            plt.close()
            
        except Exception as e:
            print(f"  ! {sta_full} 绘图失败: {e}")
            plt.close('all')

# 保存结果
try:
    import json
    summary_file = os.path.join(output_dir, "seismic_analysis_fixed.json")
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump({
            'event_info': {
                'origin_time': str(origin),
                'magnitude': evmag,
                'latitude': evla,
                'longitude': evlo,
                'depth_km': evdp
            },
            'seismic_parameters': {
                'q_factor': EARTH_Q_FACTOR,
                'crustal_velocity_km_s': CRUSTAL_VELOCITY,
                'site_amplification': SITE_AMPLIFICATION
            },
            'station_results': analysis_results
        }, f, indent=2, ensure_ascii=False)
    
    print(f"\n=== 地震学优化分析完成 ===")
    print(f"结果保存在: {output_dir}/")
    print(f"成功处理 {len(analysis_results)} 个台站")
    if len(analysis_results) > 0:
        print(f"包含P波特征识别和地震学参数优化")
except Exception as e:
    print(f"结果保存失败: {e}")
    print("分析完成，但结果保存出现问题")